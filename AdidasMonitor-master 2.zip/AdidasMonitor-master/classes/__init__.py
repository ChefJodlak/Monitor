# written by SD
# twitter.com/ciphersuites